<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="icon" type="image/gif/png" href="images/title_image.png">
		<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="stylesheet.css" type="text/css">
		<link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
		<script src="bootstrap/js/bootstrap.min.js"></script>
		<script src="jquery.min.js"></script>
</head>
<body>
	<div class="se-pre-con text-center">
		Tejas
	</div>
</body>
</html>